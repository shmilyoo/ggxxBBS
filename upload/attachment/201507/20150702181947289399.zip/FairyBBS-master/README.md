#Updates

1. I18N, L10N support 
2. a simple admin interface
3. a more reusable structure

#About

FairyBBS( [DEMO](http://fairybbs.com) ) is a BBS built on top of Django.

The reason it exists is that I like [June](https://github.com/pythoncn/june) from python-china.org but I'm not familiar with Flask.

You may need to know that this BBS is a Django project rather than an App. 
So, some modifications are needed to integrate the forum app into your own project

Besides, [June](https://github.com/pythoncn/june) is better in many ways compared with this project.

#Deployment

Django has a great document that tells how to deploy a project in production [HERE](https://docs.djangoproject.com/en/1.6/howto/deployment/)